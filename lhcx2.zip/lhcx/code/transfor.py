# -*-coding:utf-8-*_
import torch
import torch.nn as nn
import pandas as pd
import numpy as np
import math
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
# 设置随机种子
torch.manual_seed(0)

class Trans(nn.Module):
    def __init__(self, att_out: int, traget: int):
        super().__init__()
        self.input_size = att_out
        self.hidden_size = traget

        self.U_i = nn.Parameter(torch.Tensor(att_out, traget))
        self.b_i = nn.Parameter(torch.Tensor(traget))


    def init_weights(self):
        stdv = 1.0 / math.sqrt(self.hidden_size)
        for weight in self.parameters():
            weight.data.uniform_(-stdv, stdv)

    def forward(self, x, init_states=None):
        #print("输入x的梯度：", x.requires_grad)
        hidden_out = x @ self.U_i
        #print(hidden_out)

        return hidden_out



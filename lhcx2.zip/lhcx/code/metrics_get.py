# -*-coding:utf-8-*_
import os
import sys
sys.path.append('src/')
import torch
import numpy

from sklearn import metrics
from sklearn.metrics import f1_score, roc_curve, auc, recall_score, precision_score, accuracy_score
from sklearn.metrics import classification_report
from sklearn.preprocessing import label_binarize
from itertools import cycle
import matplotlib.pyplot as plt


def metrics(y_true,y_pred,epoch,batch,EPOCHS):
    def get_one_hot(number, digits=5):
        one_hot = [0] * digits
        one_hot[number] = 1

        return one_hot

    y_true = [get_one_hot(x) for x in y_true]
    y_true = torch.tensor(y_true)

    y_valid = y_true
    y_pred1 = torch.argmax(y_pred, 1)
    y_pred1 = y_pred1.detach().cpu().numpy()
    y_valid = torch.argmax(y_valid, 1)
    y_valid = y_valid.detach().cpu().numpy()

    accuracy = accuracy_score(y_valid, y_pred1)
    correct_prediction = precision_score(y_valid, y_pred1, average='micro')
    sklearn_recall = recall_score(y_valid, y_pred1, average='micro')
    sklearn_f1 = f1_score(y_valid, y_pred1, average='micro')
    if batch % 4096 ==0:
        print(f"第{epoch}个epoch的第{batch}个batch的Accuracy是{accuracy},正确率是{correct_prediction},召回率{sklearn_recall},f1_score{sklearn_f1}")

    return accuracy









  az
sys.path.append('../')
from matplotlib import pyplot as plt
from torch.autograd import Variable
from Multi_Wavelet_LSTM import Multi
from Single_Wavelet_LSTM import Single
from cross_Attention import cross_attention
from Attention import attention
from metrics_get import metrics
from sklearn.preprocessing import MaxAbsScaler
from sklearn.metrics import f1_score, roc_curve, auc, recall_score, precision_score, accuracy_score
from sklearn.metrics import classification_report
from sklearn.preprocessing import label_binarize
from itertools import cycle
import matplotlib.pyplot as plt
import torch
import torch.nn as nn
import pandas as pd
import numpy as np
import torch.utils.data as Data
import torch.nn.functional as F
import warnings
warnings.filterwarnings("ignore")

os.environ["CUDA_DEVICE_ORDER"]="PCI_BUS_ID"
os.environ["CUDA_VISIBLE_DEVICES"] = "0"

# 设置GPU
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
# 设置随机种子
torch.manual_seed(0)

EPOCHS = 200
BATCH = 32
LR = 0.001


def get_one_hot(number, digits=5):
    one_hot = [0] * digits
    one_hot[number] = 1

    return one_hot


def data_random_shuffle(x, y):
    data_num1, _, _ = x.shape  # 得到样本数
    index1 = np.arange(data_num1)  # 生成下标
    np.random.shuffle(index1)
    x1 = x[index1]
    y1 = y[index1]
    return x1, y1
device=torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
print(device)





if __name__ == '__main__':

    data_dir_path = '../data'
    train_data = pd.read_csv(data_dir_path + '/train_data0.csv', header=None)
    test_data = pd.read_csv(data_dir_path + '/test_data0.csv', header=None)

    train_np_data = train_data.values
    test_np_data = test_data.values
    train_np_data = train_np_data.T
    test_np_data = test_np_data.T
    # print(train_np_data)

    scaler = MaxAbsScaler()
    train_np_data = scaler.fit_transform(train_np_data)
    test_np_data = scaler.fit_transform(test_np_data)
    # print(train_np_data)
    train_np_data = train_np_data.T
    test_np_data = test_np_data.T
    # print(train_np_data)

    train_np_data = train_np_data.reshape(11480, 82, 6)
    test_np_data = test_np_data.reshape(2869, 82, 6)

    train_label = pd.read_csv(data_dir_path + '/train_label0.csv', header=None)
    test_label = pd.read_csv(data_dir_path + '/test_label0.csv', header=None)
    test_label_np_data = test_label.values
    train_label_np_data = train_label.values
    # print(train_label_np_data)
    # print(test_label_np_data)
    # print('----------------')

    train_np_data, train_label_np_data = data_random_shuffle(train_np_data, train_label_np_data)
    test_np_data, test_label_np_data = data_random_shuffle(test_np_data, test_label_np_data)

    train_label_np_data_2 = np.squeeze(train_label_np_data)

    test_label_np_data_2 = np.squeeze(test_label_np_data)
    # print(test_label_np_data_1)

    train_label_np_data_3 = [get_one_hot(x) for x in train_label_np_data_2]
    test_label_np_data_3 = [get_one_hot(x) for x in test_label_np_data_2]

    # train_label_np_data_3 = np.array(train_label_np_data_3).astype(np.float32)
    # test_label_np_data_3 = np.array(test_label_np_data_3).astype(np.float32)

    # train_np_data = np.array(train_np_data).astype(np.float32)
    # test_np_data = np.array(test_np_data).astype(np.float32)
    x_train, y_train, x_test, y_test = train_np_data, train_label_np_data_2, test_np_data, test_label_np_data_2
    x_train = torch.tensor(x_train)
    x_test = torch.tensor(x_test)
    y_train = torch.tensor(y_train)
    y_test = torch.tensor(y_test)
    # x_train, y_train = torch.transpose(torch.transpose(x_train, y_train, perm=[2, 0, 1]))
    # print(x_train.shape[1])
    # print(x_train.shape[2])
    train_data = Data.TensorDataset(x_train, y_train)
    test_data = Data.TensorDataset(x_test, y_test)
    train_data1 = Data.DataLoader(
        dataset=train_data,  # 数据，封装进Data.TensorDataset()类的数据
        batch_size=BATCH,  # 每块的大小
        shuffle=False,  # 要不要打乱数据 (打乱比较好)
        num_workers=16, pin_memory=True,
        drop_last=True)
    test_data1 = Data.DataLoader(
        dataset=test_data,  # 数据，封装进Data.TensorDataset()类的数据
        batch_size=x_test.shape[0],  # 每块的大小
        shuffle=False,  # 要不要打乱数据 (打乱比较好)
        num_workers=16, pin_memory=False,
        drop_last=True)

    unit_size = 32
    a = 6
    b = unit_size
    c = 6
    d = 5
    n = 5
    f = 32
    g = 5

    rnn = Multi(a, b).to(device)
    slg = Single(a, b).to(device)
    cross_at = cross_attention(d, n).to(device)
    att = attention(f, g).to(device)

    optimizerA = torch.optim.Adam(rnn.parameters(), lr=LR)
    optimizerB = torch.optim.Adam(slg.parameters(), lr=LR)
    optimizerC = torch.optim.Adam(cross_at.parameters(), lr=LR)
    optimizerD = torch.optim.Adam(att.parameters(), lr=LR)
    loss_func = nn.CrossEntropyLoss()  # 分类问题
    # 定义学习率衰减点，训练到50%和75%时学习率缩小为原来的1/10
    # mult_step_scheduler = torch.optim.lr_scheduler.MultiStepLR(optimizer1,
    # milestones=[EPOCHS // 2, EPOCHS // 4 * 3], gamma=0.1)
    loss_all = []
    loss_one_epoch = []
    loss_one_train = []
    acc_one_train = []
    for epoch in range(EPOCHS):
        print("进行第{}个epoch".format(epoch))

        loss_train = 0.0
        acc = 0.0
        batch = 0
        for step, (batch_x, batch_y) in enumerate(train_data1):
            batch_x = batch_x.to(torch.float32).to(device)
            batch_x = Variable(batch_x, requires_grad=True)
            batch_x = batch_x.view(-1, 82, 6)
            batch_y = batch_y.to(torch.long).to(device)
            # print("batch_y", batch_y)
            optimizerA.zero_grad()
            optimizerB.zero_grad()
            optimizerC.zero_grad()
            optimizerD.zero_grad()

            layer_norm = nn.LayerNorm(5).to(device)

            output1 = rnn(batch_x)
            # output1 = torch.squeeze(output1)
            # print("output1", output1)
            output1 = torch.squeeze(output1)
            mul_att_res = []
            for i in range(output1.shape[0]):
                mul_att = att(output1[i, :, :, :])
                muli_t = mul_att.detach().cpu().numpy()
                mul_att_res.append(muli_t)
            # print("mul_att_res", mul_att_res)
            mul_att_out1 = torch.tensor(mul_att_res).to(device)
            mul_att_out1 = layer_norm(mul_att_out1).to(device)

            output2 = slg(batch_x)
            output2 = torch.squeeze(output2)
            mul_att_res2 = []
            for t in range(output2.shape[0]):
                mul_att2 = att(output2[t, :, :, :])
                muli_t2 = mul_att2.detach().cpu().numpy()
                mul_att_res2.append(muli_t2)
            # print("mul_att_res", mul_att_res)

            mul_att_out2 = torch.tensor(mul_att_res).to(device)
            # print("mul_att_out", mul_att_out2.shape)
            mul_att_out2 = layer_norm(mul_att_out2).to(device)
            # print("output2_layer", mul_att_out2)
            # print("output2", output2.shape)
            coss_att = cross_at(mul_att_out1, mul_att_out2)
            # print("test_coss_att", coss_att)

            coss_att1 = torch.squeeze(coss_att)
            # print("output2", output2.shape)
            res_coss_att = coss_att1 + mul_att_out1
            # print("res_coss_att", res_coss_att.shape)
            # print("res_coss_att", res_coss_att)

            # print("输出result向量的梯度：", res_coss_att.requires_grad)

            # print("output", output.shape)
            final_output = torch.squeeze(res_coss_att)
            final_output = torch.sum(final_output, dim=1)
            final_output = F.softmax(final_output, 1)

            # print("final_output.shape", final_output.shape)
            # print("output", output)
            loss = torch.nn.functional.cross_entropy(input=final_output, target=batch_y)

            # loss.requires_grad_(True)
            #print(f"第{epoch+1}个epoch的loss", loss)

            # accuracy = ()
            # loss = loss_func(output, batch_y)
            # with autograd.detect_anomaly():
            loss.backward()
            optimizerA.step()
            optimizerB.step()
            optimizerC.step()
            optimizerD.step()
            batch += BATCH
            acc1 = metrics(batch_y, final_output, epoch, batch, EPOCHS)
            loss_train += loss.item()
            acc += acc1
        loss_one_train.append(loss_train / len(train_data1))
        acc_one_train.append(acc / len(train_data1))
        print(f"第{epoch + 1}个epoch的loss", loss_one_train[epoch])
        print(f"第{epoch + 1}个epoch的accuracy", acc_one_train[epoch])
    plt.plot(np.arange(len(loss_one_train)), loss_one_train, label="train loss")
    plt.plot(np.arange(len(acc_one_train)), acc_one_train, label="train accuracy")
    plt.legend()
    plt.xlabel("epochs")
    plt.title("Model accuracy and loss")
    plt.savefig("../figure/loss_and_acc.eps")
    plt.show()
    PATH = "../src/model.pt"
    torch.save({
        'modelA_state_dict': rnn.state_dict(),
        'modelB_state_dict': slg.state_dict(),
        'modelC_state_dict': cross_at.state_dict(),
        'modelD_state_dict': att.state_dict(),
        'optimizerA_state_dict': optimizerA.state_dict(),
        'optimizerB_state_dict': optimizerB.state_dict(),
        'optimizerC_state_dict': optimizerC.state_dict(),
        'optimizerD_state_dict': optimizerD.state_dict(),
    }, PATH)
    print("train over")







    print("-----------------------test--------------------")
    for step, (batch_x, batch_y) in enumerate(test_data1):
        batch_x = batch_x.to(torch.float32).to(device)
        batch_x = Variable(batch_x)
        batch_x = batch_x.view(-1, 82, 6)
        batch_y = batch_y.to(torch.long).to(device)
        batch_x, batch_y = torch.squeeze(batch_x), torch.squeeze(batch_y)
        layer_norm = nn.LayerNorm(5).to(device)
        output1 = rnn(batch_x)
        # output1 = torch.squeeze(output1)
        # print("output1", output1)
        output1 = torch.squeeze(output1)
        testmul_att_res = []
        for i in range(output1.shape[0]):
            mul_att = att(output1[i, :, :, :])
            muli_t = mul_att.detach().cpu().numpy()
            testmul_att_res.append(muli_t)
        # print("mul_att_res", mul_att_res)

        mul_att_out1 = torch.tensor(testmul_att_res).to(device)
        mul_att_out1 = layer_norm(mul_att_out1).to(device)


        output2 = slg(batch_x)
        output2 = torch.squeeze(output2)
        testmul_att_res2 = []
        for t in range(output2.shape[0]):
            mul_att2 = att(output2[t, :, :, :])
            muli_t2 = mul_att2.detach().cpu().numpy()
            testmul_att_res2.append(muli_t2)
        # print("mul_att_res", mul_att_res)

        mul_att_out2 = torch.tensor(testmul_att_res).to(device)
        # print("mul_att_out", mul_att_out2.shape)
        mul_att_out2 = layer_norm(mul_att_out2).to(device)
        # print("output2_layer", mul_att_out2)
        # print("output2", output2.shape)
        coss_att = cross_at(mul_att_out1, mul_att_out2)
        # print("test_coss_att", coss_att)

        coss_att1 = torch.squeeze(coss_att)
        # print("output2", output2.shape)
        res_coss_att = coss_att1 + mul_att_out1
        # print("res_coss_att", res_coss_att.shape)
        # print("res_coss_att", res_coss_att)

        # print("输出result向量的梯度：", res_coss_att.requires_grad)

        # print("output", output.shape)
        final_output = torch.squeeze(res_coss_att)
        final_output = torch.sum(final_output, dim=1)
        final_output = F.softmax(final_output, 1)

        # print("final_output.shape", final_output.shape)
        # print("output", output)
        testloss = torch.nn.functional.cross_entropy(input=final_output, target=batch_y)
        print("loss", testloss)


        def get_one_hot(number, digits=5):
            one_hot = [0] * digits
            one_hot[number] = 1

            return one_hot
        y_pred = final_output
        y_true = batch_y
        y_true = [get_one_hot(x) for x in y_true]
        y_true = torch.tensor(y_true)
        y_score = y_pred
        y_score = y_pred.detach().cpu().numpy()
        y_valid = y_true
        y_pred1 = torch.argmax(y_pred, 1)
        y_pred1 = y_pred1.detach().cpu().numpy()
        y_valid = torch.argmax(y_valid, 1)
        y_valid = y_valid.detach().cpu().numpy()


        accuracy = accuracy_score(y_valid, y_pred1)
        correct_prediction = precision_score(y_valid, y_pred1, average='micro')
        sklearn_recall = recall_score(y_valid, y_pred1, average='micro')
        sklearn_f1 = f1_score(y_valid, y_pred1, average='micro')

        print(
            f"测试的Accuracy是{accuracy},正确率是{correct_prediction},召回率{sklearn_recall},f1_score{sklearn_f1}")

        target_names = ['SGF', 'TGF', 'IPSF', 'MTF',
                        'Normal']
        class_report = classification_report(y_valid, y_pred1, target_names=target_names)
        print(class_report)
        y_valid = label_binarize(y_valid, classes=[i for i in range(5)])
        y_pred1 = label_binarize(y_pred1, classes=[i for i in range(5)])
        nb_classes = 5
        fpr = dict()
        tpr = dict()
        roc_auc = dict()

        for i in range(nb_classes):
            fpr[i], tpr[i], dfs = roc_curve(y_valid[:, i], y_score[:, i])
            roc_auc[i] = auc(fpr[i], tpr[i])

            # First aggregate all false positive rates
        all_fpr = np.unique(np.concatenate([fpr[i] for i in range(nb_classes)]))
        # Then interpolate all ROC curves at this points
        mean_tpr = np.zeros_like(all_fpr)
        for i in range(nb_classes):
            mean_tpr += np.interp(all_fpr, fpr[i], tpr[i])
            # Finally average it and compute AUC
        mean_tpr /= nb_classes
        fpr["micro"] = all_fpr
        tpr["micro"] = mean_tpr
        roc_auc["micro"] = auc(fpr["micro"], tpr["micro"])

        # Plot all ROC curves
        lw = 2
        plt.figure()
        plt.plot(fpr["micro"], tpr["micro"],
                 label='Average (AUC = {0:0.3f})'
                       ''.format(roc_auc["micro"]),
                 color='deeppink', linestyle=':', linewidth=2)
        colors = cycle(['green', 'bisque', 'salmon', 'sienna', 'plum'])
        for i, color in zip(range(nb_classes), colors):
            plt.plot(fpr[i], tpr[i], color=color, lw=lw,
                     label=target_names[i] + '(AUC = {1:0.3f})'
                                             ''.format(i, roc_auc[i]))

        plt.plot([0, 1], [0, 1], 'k--', lw=lw)
        plt.xlim([0.0, 1.0])
        plt.ylim([0.0, 1.05])
        plt.xlabel('False Positive Rate')
        plt.ylabel('True Positive Rate')
        plt.legend(loc="lower right")
        plt.show()
        plt.savefig("../figure/ROC_former_eva.eps")

    # Specify a path to save to
    
    
    


"""
    modelA = Multi(a, b)
    modelB = Single(a, b)
    modelC = cross_attention(d, n)
    modelD = attention(f, g)
    optimizerA = Multi(*args, **kwargs)
    optimizerB = Single(*args, **kwargs)
    optimizerC = cross_attention(*args, **kwargs)
    optimizerD = attention(*args, **kwargs)

    checkpoint = torch.load(PATH)
    modelA.load_state_dict(checkpoint['modelA_state_dict'])
    modelB.load_state_dict(checkpoint['modelB_state_dict'])
    modelC.load_state_dict(checkpoint['modelC_state_dict'])
    modelD.load_state_dict(checkpoint['modelD_state_dict'])
    optimizerA.load_state_dict(checkpoint['optimizerA_state_dict'])
    optimizerB.load_state_dict(checkpoint['optimizerB_state_dict'])
    optimizerC.load_state_dict(checkpoint['optimizerC_state_dict'])
    optimizerD.load_state_dict(checkpoint['optimizerD_state_dict'])

    modelA.eval()
    modelB.eval()
    modelC.eval()
    modelD.eval()"""



"""
    modelA = Net()
    modelB = Net()
    optimModelA = optim.SGD(modelA.parameters(), lr=0.001, momentum=0.9)
    optimModelB = optim.SGD(modelB.parameters(), lr=0.001, momentum=0.9)

    checkpoint = torch.load(PATH)
    modelA.load_state_dict(checkpoint['modelA_state_dict'])
    modelB.load_state_dict(checkpoint['modelB_state_dict'])
    optimizerA.load_state_dict(checkpoint['optimizerA_state_dict'])
    optimizerB.load_state_dict(checkpoint['optimizerB_state_dict'])

    modelA.eval()
    modelB.eval()
    # - or -
    modelA.train()
    modelB.train()

target_names = ['SGF', 'TGF', 'IPSF', 'MTF',
                'Normal']
class_report = classification_report(y_valid, y_pred1, target_names=target_names)
print(class_report)
y_valid = label_binarize(y_valid, classes=[i for i in range(5)])
y_pred1 = label_binarize(y_pred1, classes=[i for i in range(5)])
nb_classes = 5
fpr = dict()
tpr = dict()
roc_auc = dict()

for i in range(nb_classes):
    fpr[i], tpr[i], dfs = roc_curve(y_valid[:, i], y_score[:, i])
    roc_auc[i] = auc(fpr[i], tpr[i])

    # First aggregate all false positive rates
all_fpr = np.unique(np.concatenate([fpr[i] for i in range(nb_classes)]))
# Then interpolate all ROC curves at this points
mean_tpr = np.zeros_like(all_fpr)
for i in range(nb_classes):
    mean_tpr += np.interp(all_fpr, fpr[i], tpr[i])
    # Finally average it and compute AUC
mean_tpr /= nb_classes
fpr["micro"] = all_fpr
tpr["micro"] = mean_tpr
roc_auc["micro"] = auc(fpr["micro"], tpr["micro"])

# Plot all ROC curves
lw = 2
plt.figure()
plt.plot(fpr["micro"], tpr["micro"],
         label='Average (AUC = {0:0.3f})'
               ''.format(roc_auc["micro"]),
         color='deeppink', linestyle=':', linewidth=2)
colors = cycle(['green', 'bisque', 'salmon', 'sienna', 'plum'])
for i, color in zip(range(nb_classes), colors):
    plt.plot(fpr[i], tpr[i], color=color, lw=lw,
             label=target_names[i] + '(AUC = {1:0.3f})'
                                     ''.format(i, roc_auc[i]))

plt.plot([0, 1], [0, 1], 'k--', lw=lw)
plt.xlim([0.0, 1.0])
plt.ylim([0.0, 1.05])
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.legend(loc="lower right")
# plt.show()
plt.savefig("../ROC_former_eva.eps")
# print("Train_over")"""

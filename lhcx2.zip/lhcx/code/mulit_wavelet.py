# -*- coding: utf-8 -*-
import torch
import numpy as np
import pywt
import pywt.data
from torch.autograd import Variable
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

def waveletAlternation(SingleSample_Data):
      SingleSampleDataWavelet = SingleSample_Data.detach().cpu().numpy()
      #print("DataWavelet:", SingleSampleDataWavelet.shape)
      wavelet_result = []
      #print("wavelet_result_incipient", wavelet_result)
      for i in range(6):
            SingleSample_Data= SingleSampleDataWavelet[i]
            #print("SingleSampleDataWavelet", SingleSampleDataWavelet.shape)
            wp = pywt.WaveletPacket(SingleSample_Data, wavelet='db3', mode='symmetric', maxlevel=3)
            aaa = wp['aaa'].data #第1个节点
            aad = wp['aad'].data #第2个节点
            ada = wp['ada'].data #第3个节点
            add = wp['add'].data #第4个节点
            daa = wp['daa'].data #第5个节点
            dad = wp['dad'].data #第6个节点
            dda = wp['dda'].data #第7个节点
            ddd = wp['ddd'].data #第8个节点

            ret1 = np.linalg.norm(aaa,ord=None)
            ret2 = np.linalg.norm(aad,ord=None)
            ret3 = np.linalg.norm(ada,ord=None)
            ret5 = np.linalg.norm(daa,ord=None)
            ret4 = np.linalg.norm(add,ord=None)
            ret6 = np.linalg.norm(dad,ord=None)
            ret7 = np.linalg.norm(dda,ord=None)
            ret8 = np.linalg.norm(ddd,ord=None)

            SingleSampleFeature = [ret1, ret2, ret3, ret4, ret5, ret6, ret7, ret8]
            #SingleSampleFeature = np.array(SingleSampleFeature)
            #print("SingleSampleFeature", SingleSampleFeature)
            wavelet_result.append(SingleSampleFeature)
            #print("wavelet_result[i]", wavelet_result)
            #in_p_data = torch.Tensor(SingleSampleFeature)
            #print("in_p_data", in_p_data.shape)
            #print(in_p_data)


      #print("wavelet_result:", wavelet_result)
      wavelet_result = torch.tensor(wavelet_result).to(device)
      wavelet_result = Variable(wavelet_result, requires_grad=True)
      #print("wavelet_result的梯度：", wavelet_result.requires_grad)
      return wavelet_result

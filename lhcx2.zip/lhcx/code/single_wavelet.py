# -*- coding: utf-8 -*-
import torch
import numpy as np
import pywt
import pywt.data
from torch.autograd import Variable
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

def waveletAlternation(SingleSample_Data):
      SingleSampleDataWavelet = SingleSample_Data.detach().cpu().numpy()
      #print("DataWavelet:", SingleSampleDataWavelet.shape)
      wavelet_result = []
      #print("wavelet_result_incipient", wavelet_result)
      for i in range(6):
            SingleSample_Data= SingleSampleDataWavelet[i]
            #print("SingleSampleDataWavelet", SingleSampleDataWavelet.shape)
            wp = pywt.WaveletPacket(SingleSample_Data, wavelet='db3', mode='symmetric', maxlevel=1)
            a = wp['a'].data #第1个节点
            d = wp['d'].data #第2个节点


            ret1 = np.linalg.norm(a,ord=None)
            ret2 = np.linalg.norm(d,ord=None)


            SingleSampleFeature = [ret1, ret2]
            #SingleSampleFeature = np.array(SingleSampleFeature)
            #print("SingleSampleFeature", SingleSampleFeature)
            wavelet_result.append(SingleSampleFeature)
            #print("wavelet_result[i]", wavelet_result)
            #in_p_data = torch.Tensor(SingleSampleFeature)
            #print("in_p_data", in_p_data.shape)
            #print(in_p_data)



      wavelet_result = torch.tensor(wavelet_result).to(device)
      #print("wavelet_result:", wavelet_result.shape)
      wavelet_result = Variable(wavelet_result, requires_grad=True)
      #print("single_wavelet_result的梯度：", wavelet_result.requires_grad)
      return wavelet_result
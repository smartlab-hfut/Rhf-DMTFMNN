# -*-coding:utf-8-*_
import torch
import torch.nn as nn
import math
import torch.nn.functional as F
from transfor import Trans
from torch.autograd import Variable
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
# 设置随机种子
torch.manual_seed(0)

class attention(nn.Module):
    def __init__(self, hiddenset_len: int, attention_size: int):
        super().__init__()
        self.hiddenset_len = hiddenset_len
        #print("final_state:",hidden_set.shape)
        self.attention_size = attention_size

        # Q, K, V
        self.a_w1 = nn.Parameter(torch.Tensor(hiddenset_len, attention_size))
        #self.a_b1 = nn.Parameter(torch.Tensor(attention_size))
        self.a_w2 = nn.Parameter(torch.Tensor(hiddenset_len, attention_size))
        #self.a_b2 = nn.Parameter(torch.Tensor(attention_size))
        self.a_w3 = nn.Parameter(torch.Tensor(hiddenset_len, attention_size))
        #self.a_b3 = nn.Parameter(torch.Tensor(attention_size))
        #
        self.init_weights()

    def init_weights(self):
            stdv = 1.0 / math.sqrt(self.attention_size)
            for weight in self.parameters():
                weight.data.uniform_(-stdv, stdv)

    def forward(self, x):
        x = x.to(torch.float32)
        #print("x", x.shape)
        a = Variable(x, requires_grad=True)
        #print("a", a)


        #print("att中x的梯度", x.requires_grad)
        #print("x", x.shape)
        a = torch.squeeze(a)
        #print("a", a.shape)
        Q = torch.matmul(a, self.a_w1)
        #print("Q:", Q.shape)
        K = torch.matmul(a, self.a_w2)
        #print("K:", K.shape)
        V = torch.matmul(a, self.a_w3)
        #print("V:", V.shape)
        #print("K转置", K.permute(0, 2, 1).shape)
        ei = torch.bmm(Q, K.permute(0, 2, 1 ))
        #print("ei", ei.shape)
        score = F.softmax(ei, 1)
        #print("crossat_score.shape", score.shape)
        #print("crossat_score.shape", score)
        #print("score", score)
        u = torch.matmul(score, V)
        u1 = torch.sum(u, dim=0)
        #print("cross_att输出的u的向量的梯度：", u.requires_grad)
        #print("u1", u1.shape)
        #feat = torch.sum(u, dim=1)
        #print("feat", feat.shape)
        #a = 32
        #c = 5
        #trans = Trans(a, c).to(device)
        outs = u1
        #print("att中out的梯度", outs.requires_grad)
        #print("outs.shape:", outs.shape)

        return outs


import math

import numpy as np
import torch
import torch.nn as nn
from single_wavelet import waveletAlternation

from torch.autograd import Variable

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
# 设置随机种子
torch.manual_seed(0)



class Single(nn.Module):
    def __init__(self, input_sz: int, hidden_sz: int):
        super().__init__()
        self.input_size = input_sz
        self.hidden_size = hidden_sz
        #print(self.input_size)



        # i_t
        self.U_i = nn.Parameter(torch.Tensor(input_sz, hidden_sz))
        self.V_i = nn.Parameter(torch.Tensor(hidden_sz, hidden_sz))
        self.b_i = nn.Parameter(torch.Tensor(hidden_sz))

        #print("self.U_i", self.U_i.shape)
        #print("self.V_i", self.V_i.shape)
        #print("self.b_i",self.b_i.shape)

        # f_t
        self.U_f = nn.Parameter(torch.Tensor(input_sz, hidden_sz))
        self.V_f = nn.Parameter(torch.Tensor(hidden_sz, hidden_sz))
        self.b_f = nn.Parameter(torch.Tensor(hidden_sz))
        #print("self.U_f",self.U_f.shape)
        #print("self.V_f",self.V_f.shape)
        #print("self.b_f",self.b_f.shape)

        # c_t
        self.U_c = nn.Parameter(torch.Tensor(input_sz, hidden_sz))
        self.V_c = nn.Parameter(torch.Tensor(hidden_sz, hidden_sz))
        self.b_c = nn.Parameter(torch.Tensor(hidden_sz))
        #print("self.U_c",self.U_c.shape)
        #print("self.V_c",self.V_c.shape)
        #print("self.b_c",self.b_c.shape)

        # o_t
        self.U_o = nn.Parameter(torch.Tensor(input_sz, hidden_sz))
        self.V_o = nn.Parameter(torch.Tensor(hidden_sz, hidden_sz))
        self.b_o = nn.Parameter(torch.Tensor(hidden_sz))
        #print("self.U_o",self.U_o.shape)
        #print("self.V_o",self.V_o.shape)
        #print("self.b_o",self.b_o.shape)

        # wavelet
        self.W_w = nn.Parameter(torch.Tensor(hidden_sz))
        self.b_w = nn.Parameter(torch.Tensor(hidden_sz))

        #wavelet_result
        self.W_c = nn.Parameter(torch.Tensor(2, hidden_sz))
        self.b_q = nn.Parameter(torch.Tensor(hidden_sz))

        self.init_weights()

    def init_weights(self):
        stdv = 1.0 / math.sqrt(self.hidden_size)
        for weight in self.parameters():
            weight.data.uniform_(-stdv, stdv)


    def forward(self, x, init_states=None):

        """
        assumes x.shape represents (batch_size, sequence_size, input_size)
        """
        bs, seq_sz, _ = x.size()
        x = x.to(torch.float32)
        #print("single输入x的梯度：", x.requires_grad)
        #print("x", x.shape)

        h_t1 = torch.zeros(_, self.hidden_size).to(x.device)
        #print("initial_h_t1:", h_t1)

        if init_states is None:
            h_tt, c_t = (
                torch.zeros(_, self.hidden_size).to(x.device),
                torch.zeros(_, self.hidden_size).to(x.device),
            )
        else:
            h_tt, c_t = init_states
        hidden_seq1 = []
        hidden_seq2 = []
        hidden_seq = []
        attl = []
        for i in range(bs):
            hiddense = []
            hidd_at = []
            hidd_a = []
            a = 32
            b = 64
            #attc = attention_net(a, b).to(device)#第i个batch中
            for t in range(seq_sz):#每个时间步循环
                x_t = x[i, t, :]#第i个batch中第t个时间步输入数据
                #print("X_t: ", x_t.shape)
                i_t = torch.sigmoid(x_t @ self.U_i + h_tt @ self.V_i + self.b_i)
                f_t = torch.sigmoid(x_t @ self.U_f + h_tt @ self.V_f + self.b_f)
                g_t = torch.tanh(x_t @ self.U_c + h_tt @ self.V_c + self.b_c)
                o_t = torch.sigmoid(x_t @ self.U_o + h_tt @ self.V_o + self.b_o)
                #print(i_t.shape, f_t.shape, g_t.shape, o_t.shape)
                #vv = f_t * c_t
                #print("vv",vv.shape)
                in_p = i_t * g_t
                #print("in_p:", in_p.shape)
                #in_p = in_p.detach().numpy()
                in_p_data = waveletAlternation(in_p)
                #print(in_p_data.shape)
                in_p_wavelet = torch.tanh(in_p_data @ self.W_c + self.b_q)
                #print("wavelet_result_out", in_p_data.shape)
                #in_p_wavelet = torch.sigmoid(self.W_w @ in_p_data + self.b_b)
                #print(in_p_wavelet.shape)
                c_t = f_t * c_t + in_p_wavelet
                h_t = o_t * torch.tanh(c_t)
                h_tt = h_t #传入下一时刻的隐藏状态
                h_tn = h_tt.detach().cpu().numpy()
                #print("h_tn", h_tn)
                hiddense.append(h_tn)
                #hidist = hiddense.append(h_t.unsqueeze(0))#当前时刻隐藏状态加入数组中
                #h_t1 = torch.stack((hiddense, h_tt), dim=1)
                #print("h_t1", h_t1)
                #print("ma.shape:", ma)
            #hidden_seq = torch.cat(h_t1, dim=0)#concatnating tensor
            #hidstack = hidden_seq.append(h_t1.unsqueeze(0))
            hidden_seq.append(hiddense)#储存第i个样本的隐藏状态
            hidd_at.append(hiddense)
            #hidd_a = torch.tensor(hidd_at)
            #print("hidden_s", hidden_seq)
            #hidden_seq1 = torch.tensor(hidden_seq)
            #print("hidden_seq1.shape", hidden_seq1.shape)
            #att = attc(hidd_a)
            #print("att,", att.shape)
            #att1 = att.detach().numpy()
            #attl.append(att1)
            #hidden_att = torch.tensor(attl)
            #print("hidden_att", hidden_att.shape)
        hidden_seq2.append(hidden_seq)
        hidden_att_bs = torch.tensor(hidden_seq2).to(device)
        #print("single_lstm", hidden_att_bs.shape)
        hidden_att_bs = Variable(hidden_att_bs, requires_grad=True)
        #print("single over")
        #print("hidden_att_bs", hidden_att_bs.shape)

            #print("hidden_s.shape", hidden_att.shape)

        return hidden_att_bs
